# Quoridor Elmasry Proguard Rules
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.elmasry.quoridor.WebAppInterface { *; }
