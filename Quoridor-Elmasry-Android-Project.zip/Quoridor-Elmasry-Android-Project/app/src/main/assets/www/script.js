// تعريف ملف الصوت باستخدام Howler
const wallSound = new Howl({
    src: ['fahhh_KcgAXfs.mp3'],
    volume: 1.0
});

const COL=[0xd62828,0x1d6fe0,0x2fa84f,0xf2c21b],HEX=['#d62828','#1d6fe0','#2fa84f','#f2c21b'],NAMES=['الأحمر','الأزرق','الأخضر','الأصفر'],D4=[[0,1],[0,-1],[1,0],[-1,0]],P=1.2;
const PR={fast:{p:.1,th:3},bal:{p:.5,th:2},def:{p:.9,th:1},agg:{p:1,th:1},sly:{p:.65,th:2}};
const $=id=>document.getElementById(id),cl=(v,a,b)=>Math.max(a,Math.min(b,v));
let N=9,c=4,NP=2,WIN=1,mode='local',SND=true,G,pawns=[],hl=[],ghost=null,fx=[],star=null,shake=0,pv={x:3,y:3,o:'h'};
const inb=(x,y)=>x>=0&&y>=0&&x<N&&y<N,X=x=>(x-c)*P;

let AC;const au=()=>{if(!AC)try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}if(AC&&AC.state=='suspended')AC.resume();return AC};
function tone(f,d,ty='sine',v=.2,f2,t0=0){if(!SND||!au())return;const o=AC.createOscillator(),g=AC.createGain(),t=AC.currentTime+t0;o.type=ty;o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(AC.destination);o.start(t);o.stop(t+d);}
function noise(d,v,f1,f2,t0=0){if(!SND||!au())return;const n=Math.floor(AC.sampleRate*d),b=AC.createBuffer(1,n,AC.sampleRate),a=b.getChannelData(0);for(let i=0;i<n;i++)a[i]=Math.random()*2-1;
 const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain(),t=AC.currentTime+t0;s.buffer=b;f.type='lowpass';f.frequency.setValueAtTime(f1,t);f.frequency.exponentialRampToValueAtTime(f2,t+d);
 g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);}
const sMove=()=>{tone(520,.09,'triangle',.18,300);noise(.05,.15,3000,800)},sErr=()=>tone(140,.25,'sawtooth',.14,90),sTick=()=>tone(700,.05,'square',.06);
const sWhoosh=()=>{noise(.9,.3,4000,150);tone(1000,.9,'sine',.07,90);tone(55,1,'sawtooth',.12,200)};
const sBoom=()=>{tone(95,.8,'sine',.95,22);noise(.6,.9,900,50);tone(55,1,'square',.25,18);tone(200,.15,'sawtooth',.3,40)};
const sStar=()=>[660,880,1320].forEach((f,i)=>tone(f,.25,'triangle',.18,0,i*.09)),sWin=()=>[523,659,784,1047,1319].forEach((f,i)=>tone(f,.4,'triangle',.2,0,i*.14));

// موسيقى هادئة في الخلفية
function playAmbientChill() {
    if(!SND || !au()) return;
    const notes = [261.63, 329.63, 392.00, 523.25, 587.33];
    const f = notes[Math.floor(Math.random() * notes.length)];
    const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime;
    o.type = 'sine';
    o.frequency.setValueAtTime(f, t);
    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.04, t + 1.5);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 4.5);
    o.connect(g); g.connect(AC.destination);
    o.start(t); o.stop(t + 4.5);
}
setInterval(() => { if(SND) playAmbientChill(); }, 5000);

function blk(ax,ay,bx,by,W=G.walls){
 if(ax==bx){const r=Math.min(ay,by);return W.some(w=>w.o=='h'&&w.y==r&&(w.x==ax||w.x==ax-1));}
 const k=Math.min(ax,bx);return W.some(w=>w.o=='v'&&w.x==k&&(w.y==ay||w.y==ay-1));}
const isGoal=(p,x,y)=>WIN>=3?(x==G.star.x&&y==G.star.y):p.ax=='y'?y==p.gv:x==p.gv;
const occ=(x,y,i)=>G.p.some((q,j)=>j!=i&&q.x==x&&q.y==y);
function moves(i){const me=G.p[i],out=[];
 for(const[dx,dy]of D4){const nx=me.x+dx,ny=me.y+dy;if(!inb(nx,ny)||blk(me.x,me.y,nx,ny))continue;
  if(!occ(nx,ny,i)){out.push([nx,ny]);continue;}
  const jx=nx+dx,jy=ny+dy;
  if(inb(jx,jy)&&!blk(nx,ny,jx,jy)&&!occ(jx,jy,i))out.push([jx,jy]);
  else for(const[sx,sy]of[[dy,dx],[-dy,-dx]]){const tx=nx+sx,ty=ny+sy;if(inb(tx,ty)&&!blk(nx,ny,tx,ty)&&!occ(tx,ty,i))out.push([tx,ty]);}}
 return out;}
function dist(x,y,p,W){const d=new Map([[x*N+y,0]]),q=[[x,y]];
 for(let i=0;i<q.length;i++){const[cx,cy]=q[i],k=d.get(cx*N+cy);if(isGoal(p,cx,cy))return k;
  for(const[dx,dy]of D4){const nx=cx+dx,ny=cy+dy;if(inb(nx,ny)&&!d.has(nx*N+ny)&&!blk(cx,cy,nx,ny,W)){d.set(nx*N+ny,k+1);q.push([nx,ny]);}}}
 return 1e9;}
function wallErr(w){
 if(w.x<0||w.y<0||w.x>N-2||w.y>N-2)return 'الجدار خارج اللوحة';
 for(const e of G.walls){if(e.x==w.x&&e.y==w.y)return 'الجدار يتقاطع مع جدار آخر';
  if(e.o==w.o&&(w.o=='h'?(e.y==w.y&&Math.abs(e.x-w.x)==1):(e.x==w.x&&Math.abs(e.y-w.y)==1)))return 'الجدار يتداخل مع جدار آخر';}
 const W=[...G.walls,w];
 if(G.p.some(p=>dist(p.x,p.y,p,W)>=1e9))return 'مرفوض: هذا الجدار يسدّ الطريق تماماً أمام لاعب';
 return null;}

const R=new THREE.WebGLRenderer({canvas:$('cv'),antialias:true});
R.shadowMap.enabled=true;
R.shadowMap.type=THREE.PCFSoftShadowMap;
R.setPixelRatio(Math.min(devicePixelRatio,2));

const S=new THREE.Scene();
S.background=new THREE.Color(0x2d170a);
S.fog=new THREE.FogExp2(0xd6853c, 0.007);
const C=new THREE.PerspectiveCamera(45,1,.1,500);

// Atmospheric Desert Lighting with Soft Shadows
S.add(new THREE.HemisphereLight(0xfff3d8, 0x7a4d25, 0.9));
const L=new THREE.DirectionalLight(0xffe2a4, 1.15);
L.position.set(-16, 24, 18);
L.castShadow=true;
L.shadow.mapSize.set(2048, 2048);
L.shadow.radius = 3.2;
L.shadow.bias = -0.0004;
S.add(L);

// Ambient fill light for rich shadows
const fillLight=new THREE.DirectionalLight(0xb86c2e, 0.4);
fillLight.position.set(18, 12, -18);
S.add(fillLight);

// توليد ملمس الحجر الرملي الدقيق للأرضية والبلاطات (Sandstone Grain Texture)
function mkSandstoneTexture(){
    const cv=document.createElement('canvas');cv.width=128;cv.height=128;
    const ctx=cv.getContext('2d');
    ctx.fillStyle='#808080';ctx.fillRect(0,0,128,128);
    const imgData=ctx.getImageData(0,0,128,128);
    for(let i=0;i<imgData.data.length;i+=4){
        const n=(Math.random()-.5)*55;
        const v=Math.max(0,Math.min(255,128+n));
        imgData.data[i]=v;imgData.data[i+1]=v;imgData.data[i+2]=v;
    }
    ctx.putImageData(imgData,0,0);
    const tex=new THREE.CanvasTexture(cv);
    tex.wrapS=tex.wrapT=THREE.RepeatWrapping;
    tex.repeat.set(16,16);
    return tex;
}
const sandBumpTex=mkSandstoneTexture();

// نسيج تظليل الإضاءة المحيطية التلامسية (Ambient Occlusion Contact Shadow)
function mkContactAoTexture(){
    const cv=document.createElement('canvas');cv.width=64;cv.height=64;
    const ctx=cv.getContext('2d');
    const g=ctx.createRadialGradient(32,32,4,32,32,30);
    g.addColorStop(0,'rgba(0,0,0,0.85)');
    g.addColorStop(0.5,'rgba(18,10,4,0.45)');
    g.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=g;ctx.fillRect(0,0,64,64);
    return new THREE.CanvasTexture(cv);
}
const aoTex=mkContactAoTexture();

const M=(k,r=.75,m=0)=>{
    const mat=new THREE.MeshStandardMaterial({color:k,roughness:r,metalness:m});
    mat.bumpMap=sandBumpTex;
    mat.bumpScale=0.03;
    return mat;
};
const B=new THREE.Group();S.add(B);
const add=(g,m,x,y,z,sh,par=B)=>{const o=new THREE.Mesh(g,m);o.position.set(x,y,z);o.receiveShadow=true;o.castShadow=!!sh;par.add(o);return o;};

// 1. Procedural Sky Dome with glowing sunset & Sun disc
function mkSkyTexture(){
    const cv=document.createElement('canvas');cv.width=256;cv.height=512;
    const ctx=cv.getContext('2d');
    const g=ctx.createLinearGradient(0,0,0,512);
    g.addColorStop(0,'#140b06');
    g.addColorStop(0.35,'#3a180b');
    g.addColorStop(0.62,'#994417');
    g.addColorStop(0.82,'#d67a28');
    g.addColorStop(1,'#f5b563');
    ctx.fillStyle=g;ctx.fillRect(0,0,256,512);
    // Setting Egyptian sun
    const sG=ctx.createRadialGradient(128,400,8,128,400,85);
    sG.addColorStop(0,'rgba(255,254,235,1)');
    sG.addColorStop(0.2,'rgba(255,225,140,0.9)');
    sG.addColorStop(0.55,'rgba(240,140,50,0.3)');
    sG.addColorStop(1,'rgba(240,140,50,0)');
    ctx.fillStyle=sG;ctx.beginPath();ctx.arc(128,400,85,0,Math.PI*2);ctx.fill();
    return new THREE.CanvasTexture(cv);
}
const skyDome=new THREE.Mesh(new THREE.SphereGeometry(380,32,16),new THREE.MeshBasicMaterial({map:mkSkyTexture(),side:THREE.BackSide,depthWrite:false}));
S.add(skyDome);

// 2. Desert Dunes and Terrain
const gnd=add(new THREE.PlaneGeometry(1000,1000),M(0xd6a152,.92,.02),0,-.65,0,0,S);
gnd.rotation.x=-Math.PI/2;

const dunesGroup=new THREE.Group();S.add(dunesGroup);
[
    [-110,-120,70,16,0.22,0xba7c35],
    [0,-145,100,22,-0.12,0xba7c35],
    [105,-115,75,18,0.28,0xba7c35],
    [-70,-80,48,13,-0.22,0xca8c3e],
    [70,-70,52,14,0.18,0xca8c3e]
].forEach(([x,z,rx,ry,rot,col])=>{
    const d=new THREE.Mesh(new THREE.ConeGeometry(rx,ry,18),M(col,.9,.05));
    d.position.set(x,ry*0.45-.65,z);
    d.scale.set(1.4,0.4,0.8);
    d.rotation.z=rot;
    dunesGroup.add(d);
});

// 3. Three Great Pyramids with Stepped Masonry & Gleaming Golden Pyramidions
function mkPyramid(baseW,height,tiers,x,z){
    const grp=new THREE.Group();
    const stoneMat=M(0xc89b55,.88,.05);
    const goldMat=new THREE.MeshStandardMaterial({color:0xffd538,metalness:.95,roughness:.18,emissive:0x6e4802,emissiveIntensity:.4});
    const tH=height/(tiers+1);
    for(let i=0;i<tiers;i++){
        const f1=i/(tiers+1),f2=(i+1)/(tiers+1);
        const wTop=baseW*(1-f2*.88)*.707,wBot=baseW*(1-f1*.88)*.707;
        const t=new THREE.Mesh(new THREE.CylinderGeometry(wTop,wBot,tH,4),stoneMat);
        t.position.y=i*tH+tH/2;t.rotation.y=Math.PI/4;t.castShadow=true;t.receiveShadow=true;grp.add(t);
    }
    const topW=baseW*(1-tiers/(tiers+1)*.88)*.707,capH=tH*1.5;
    const cap=new THREE.Mesh(new THREE.ConeGeometry(topW,capH,4),goldMat);
    cap.position.y=tiers*tH+capH/2;cap.rotation.y=Math.PI/4;cap.castShadow=true;grp.add(cap);
    grp.position.set(x,-.65,z);S.add(grp);return grp;
}
mkPyramid(46,38,7,34,-100);  // Khufu
mkPyramid(38,33,6,-42,-85);  // Khafre
mkPyramid(22,19,5,80,-60);   // Menkaure

// 4. Twin Sacred Obelisks flanking the temple horizon
function mkObelisk(x,z,h,s){
    const g=new THREE.Group();
    const stMat=M(0xc08e4a,.8,.1),gdMat=new THREE.MeshStandardMaterial({color:0xffd538,metalness:.92,roughness:.2});
    const b1=new THREE.Mesh(new THREE.BoxGeometry(s*1.6,s*.6,s*1.6),stMat);b1.position.y=s*.3;
    const b2=new THREE.Mesh(new THREE.BoxGeometry(s*1.2,s*.4,s*1.2),stMat);b2.position.y=s*.7;
    const shaft=new THREE.Mesh(new THREE.CylinderGeometry(s*.32,s*.48,h,4),stMat);shaft.position.y=s*.9+h/2;shaft.rotation.y=Math.PI/4;
    const top=new THREE.Mesh(new THREE.ConeGeometry(s*.32,s*1.1,4),gdMat);top.position.y=s*.9+h+s*.55;top.rotation.y=Math.PI/4;
    g.add(b1,b2,shaft,top);g.position.set(x,-.65,z);g.traverse(o=>{o.castShadow=true;o.receiveShadow=true;});
    S.add(g);return g;
}
mkObelisk(-22,-38,14,2.2);
mkObelisk(22,-38,14,2.2);

// 5. Ambient Floating Golden Embers
const embers=[];
const emberGeo=new THREE.SphereGeometry(.06,6,6);
const emberMat=new THREE.MeshBasicMaterial({color:0xffd44a,transparent:true,opacity:.75});
for(let i=0;i<45;i++){
    const m=new THREE.Mesh(emberGeo,emberMat);
    m.position.set((Math.random()-.5)*36,Math.random()*12,(Math.random()-.5)*36);
    m.userData={speedY:.008+Math.random()*.015,phase:Math.random()*Math.PI*2};
    S.add(m);embers.push(m);
}

const torchLights=[];
const torchFlames=[];
const cg=new THREE.BoxGeometry(1,.24,1);
const tint=(x,y)=>WIN==1?(y==0?0xe3a595:y==N-1&&NP>=2?0x9fbbe6:x==N-1&&NP>=3?0xa5d9a0:x==0&&NP>=4?0xe8dc8a:0):WIN==2&&y==0?0xf2d37a:0;

function buildBoard(){
    B.clear();
    torchLights.length=0;
    torchFlames.length=0;
    const w=N*P;

    // 0. Ambient Occlusion Contact Shadow underneath the board
    const aoPlinth = new THREE.Mesh(
        new THREE.PlaneGeometry(w + 4.2, w + 4.2),
        new THREE.MeshBasicMaterial({map: aoTex, transparent: true, opacity: 0.75, depthWrite: false})
    );
    aoPlinth.rotation.x = -Math.PI / 2;
    aoPlinth.position.y = -0.64;
    B.add(aoPlinth);

    // 1. Pharaonic Multi-Tier Royal Base (المصطبة الفرعونية المذهبة)
    // Dark polished basalt bottom tier
    add(new THREE.BoxGeometry(w+2.2,.45,w+2.2), M(0x161310,.35,.3), 0, -.45, 0);
    // Gleaming gold inlaid perimeter border
    add(new THREE.BoxGeometry(w+1.2,.22,w+1.2), new THREE.MeshStandardMaterial({color:0xdfa732,metalness:.88,roughness:.22}), 0, -.22, 0);
    // Dark sandstone inner bed
    add(new THREE.BoxGeometry(w+.4,.18,w+.4), M(0x261d14,.7,.15), 0, -.14, 0);

    // 2. Beveled Alabaster & Sandstone Grid Tiles
    for(let x=0;x<N;x++)for(let y=0;y<N;y++){
        const isGoal=tint(x,y);
        const tileColor=isGoal||((x+y)%2?0xe0c48e:0xcca065);
        const tileMat=M(tileColor,isGoal?.4:.65,isGoal?.2:.05);
        if(isGoal){tileMat.emissive=new THREE.Color(isGoal);tileMat.emissiveIntensity=.25;}
        add(cg,tileMat,X(x),-.06,X(y));
    }

    // 3. Ornate Corner Columns with Living Fire Torches
    const e=w/2+1.05;
    for(const sx of[-1,1])for(const sz of[-1,1]){
        const x=sx*e,z=sz*e;
        // Basalt stepped pedestal
        add(new THREE.CylinderGeometry(.62,.72,.35,16),M(0x1a1612,.4,.3),x,.17,z,1);
        add(new THREE.CylinderGeometry(.52,.62,.15,16),new THREE.MeshStandardMaterial({color:0xdfa732,metalness:.85,roughness:.25}),x,.42,z,1);
        // Fluted column shaft
        add(new THREE.CylinderGeometry(.44,.48,3.6,16),M(0xdcc08a,.75,.05),x,2.3,z,1);
        // Golden collar rings on shaft
        add(new THREE.TorusGeometry(.47,.035,8,20),new THREE.MeshStandardMaterial({color:0xdfa732,metalness:.88,roughness:.22}),x,1.5,z).rotation.x=Math.PI/2;
        add(new THREE.TorusGeometry(.47,.035,8,20),new THREE.MeshStandardMaterial({color:0xdfa732,metalness:.88,roughness:.22}),x,3.1,z).rotation.x=Math.PI/2;
        // Flared Lotus / Papyrus Capital
        add(new THREE.CylinderGeometry(.8,.44,.65,16),M(0xdcc08a,.7,.1),x,4.3,z,1);
        add(new THREE.CylinderGeometry(.82,.78,.12,16),new THREE.MeshStandardMaterial({color:0xdfa732,metalness:.85,roughness:.25}),x,4.65,z,1);
        // Bronze Brazier Bowl
        add(new THREE.CylinderGeometry(.72,.45,.35,16),new THREE.MeshStandardMaterial({color:0x462810,metalness:.75,roughness:.35}),x,4.85,z,1);
        // Burning Coals
        add(new THREE.CylinderGeometry(.62,.62,.1,12),new THREE.MeshStandardMaterial({color:0xff3300,emissive:0xff2200,emissiveIntensity:1}),x,4.95,z);

        // Living 3D Animated Flame
        const flameGrp=new THREE.Group();
        const fOuter=new THREE.Mesh(new THREE.ConeGeometry(.28,.8,8),new THREE.MeshBasicMaterial({color:0xff7c10,transparent:true,opacity:.88}));
        fOuter.position.y=.4;
        const fInner=new THREE.Mesh(new THREE.ConeGeometry(.16,.58,8),new THREE.MeshBasicMaterial({color:0xffe040,transparent:true,opacity:.95}));
        fInner.position.y=.3;
        flameGrp.add(fOuter,fInner);
        flameGrp.position.set(x,5.0,z);
        B.add(flameGrp);
        torchFlames.push(flameGrp);

        // Dynamic Fire PointLight illuminating the board
        const pl=new THREE.PointLight(0xff9425,1.25,18);
        pl.position.set(x,5.3,z);
        B.add(pl);
        torchLights.push(pl);
    }

    const s=w/2+3;Object.assign(L.shadow.camera,{left:-s,right:s,top:s,bottom:-s,near:1,far:70});L.shadow.camera.updateProjectionMatrix();
}

const D=new THREE.Group();S.add(D);

// Majestic Pharaonic Royal Pawns (تماثيل الفراعنة الملكية المذهبة)
function mkPawn(k){
    const g=new THREE.Group();
    const goldMat=new THREE.MeshStandardMaterial({color:0xf5c338,metalness:.9,roughness:.2});
    const jewelMat=new THREE.MeshStandardMaterial({color:k,roughness:.28,metalness:.25});
    const darkMat=new THREE.MeshStandardMaterial({color:0x1a1510,roughness:.4,metalness:.4});
    const rubyMat=new THREE.MeshStandardMaterial({color:0xdc143c,roughness:.2,metalness:.3,emissive:0x550011,emissiveIntensity:.4});

    const addMesh=(geo,mt,y=0,rotY=0)=>{
        const o=new THREE.Mesh(geo,mt);o.position.y=y;o.rotation.y=rotY;o.castShadow=true;o.receiveShadow=true;g.add(o);return o;
    };

    // 1. Royal Pedestal Base (Plinth)
    addMesh(new THREE.CylinderGeometry(.44,.48,.12,24),darkMat,.06);
    addMesh(new THREE.CylinderGeometry(.41,.44,.06,24),goldMat,.13);
    addMesh(new THREE.CylinderGeometry(.38,.41,.04,24),jewelMat,.17);

    // 2. Pharaoh Royal Tunic (fluted torso)
    addMesh(new THREE.CylinderGeometry(.18,.34,.65,20),jewelMat,.52);
    // Golden Royal Belt
    const belt=addMesh(new THREE.TorusGeometry(.29,.035,10,24),goldMat,.35);belt.rotation.x=Math.PI/2;
    const buckle=new THREE.Mesh(new THREE.BoxGeometry(.08,.1,.05),goldMat);buckle.position.set(0,.35,.3);g.add(buckle);

    // 3. Royal Broad Collar (قلادة الأوسخ الفرعونية - Usekh)
    const collar=addMesh(new THREE.TorusGeometry(.24,.045,10,24),goldMat,.76);collar.rotation.x=Math.PI/2;
    const collarInner=addMesh(new THREE.TorusGeometry(.19,.03,8,20),jewelMat,.81);collarInner.rotation.x=Math.PI/2;

    // 4. Pharaoh Head
    addMesh(new THREE.SphereGeometry(.19,24,18),goldMat,.98);

    // 5. Iconic Nemes Royal Headdress (غطاء الرأس الملكي النمس)
    const hood=addMesh(new THREE.CylinderGeometry(.27,.22,.35,18),jewelMat,1.15);
    hood.scale.set(1.15,1,1.25);
    const hoodRim=addMesh(new THREE.TorusGeometry(.25,.025,8,20),goldMat,1.16);hoodRim.rotation.x=Math.PI/2;
    addMesh(new THREE.ConeGeometry(.28,.22,4),goldMat,1.34,Math.PI/4);

    // Two side lappets (طيات النمس المنسدلة على الكتفين)
    const lappetGeo=new THREE.BoxGeometry(.07,.38,.09);
    const lapL=new THREE.Mesh(lappetGeo,goldMat);lapL.position.set(-.21,.84,.08);lapL.rotation.z=-.15;
    const lapR=new THREE.Mesh(lappetGeo,goldMat);lapR.position.set(.21,.84,.08);lapR.rotation.z=.15;
    g.add(lapL,lapR);

    // Pharaoh's braided false beard (اللحية الملكية المستعارة)
    const beard=new THREE.Mesh(new THREE.CylinderGeometry(.025,.04,.2,8),goldMat);
    beard.position.set(0,.82,.18);beard.rotation.x=-.2;g.add(beard);

    // 6. Royal Uraeus Cobra on forehead (أفعى الكوبرا الملكية)
    const cobraStem=new THREE.Mesh(new THREE.CylinderGeometry(.02,.02,.12,6),goldMat);
    cobraStem.position.set(0,1.14,.23);cobraStem.rotation.x=.3;
    const cobraHood=new THREE.Mesh(new THREE.SphereGeometry(.045,12,8),goldMat);
    cobraHood.position.set(0,1.22,.25);cobraHood.scale.set(1.5,1,.6);
    const rubyEye=new THREE.Mesh(new THREE.SphereGeometry(.018,8,8),rubyMat);
    rubyEye.position.set(0,1.23,.28);g.add(cobraStem,cobraHood,rubyEye);

    // 7. Active Turn Aura Glyph Ring (حلقة الإشعاع الفرعونية)
    const auraRing=new THREE.Mesh(
        new THREE.RingGeometry(.46,.62,32),
        new THREE.MeshBasicMaterial({color:k,transparent:true,opacity:0,side:THREE.DoubleSide})
    );
    auraRing.rotation.x=-Math.PI/2;auraRing.position.y=.02;g.add(auraRing);
    g.userData.auraRing=auraRing;
    g.userData.baseColor=k;
    return g;
}

// Egyptian Carved Sandstone Walls (الجدران الفرعونية المطعمة بالذهب)
function mkWall(w,k,gh){
    const g=new THREE.Group(),h=w.o=='h';
    const stoneCol=gh?k:0xd8ab66;
    const m=M(stoneCol,gh?.4:.7,gh?0:.1);
    if(gh){m.transparent=true;m.opacity=.65;}

    const wallW=h?2.22:.26;
    const wallD=h?.26:2.22;
    const wallH=.72;

    // Main carved sandstone block
    const b=new THREE.Mesh(new THREE.BoxGeometry(wallW,wallH,wallD),m);
    b.position.y=wallH/2;

    // Gilded Cartouche Top Slab
    const goldMat=gh?m:new THREE.MeshStandardMaterial({color:0xf5c338,metalness:.85,roughness:.25,emissive:0x3d2805,emissiveIntensity:.2});
    const cap=new THREE.Mesh(new THREE.BoxGeometry(h?2.28:.32,.09,h?.32:2.28),goldMat);
    cap.position.y=wallH+.045;

    // End studs / Hieroglyphic corner brackets
    const studMat=gh?m:M(0x5a3d1c,.5,.5);
    const s1=new THREE.Mesh(new THREE.BoxGeometry(h?.12:.28,.74,h?.28:.12),studMat);
    s1.position.set(h?-1.06:0,wallH/2,h?0:-1.06);
    const s2=new THREE.Mesh(new THREE.BoxGeometry(h?.12:.28,.74,h?.28:.12),studMat);
    s2.position.set(h?1.06:0,wallH/2,h?0:1.06);

    // Player color jewel ribbon in center
    const ribbonMat=gh?m:new THREE.MeshStandardMaterial({color:k,roughness:.3,metalness:.4});
    const ribbon=new THREE.Mesh(new THREE.BoxGeometry(h?.4:.28,.14,h?.28:.4),ribbonMat);
    ribbon.position.y=wallH/2;

    // Ambient Occlusion Contact Shadow underneath wall
    const wallAo=new THREE.Mesh(
        new THREE.PlaneGeometry(h?2.38:.44, h?.44:2.38),
        new THREE.MeshBasicMaterial({map:aoTex, transparent:true, opacity:gh?.25:.68, depthWrite:false})
    );
    wallAo.rotation.x=-Math.PI/2;
    wallAo.position.y=0.005;

    g.add(b,cap,s1,s2,ribbon,wallAo);
    g.traverse(o=>{o.castShadow=!gh;o.receiveShadow=!gh;});
    g.userData.bm=m;
    g.userData.goldCap=cap;
    g.position.set((w.x+.5-c)*P,0,(w.y+.5-c)*P);
    return g;
}

function mkStar(){const s=new THREE.Shape();for(let i=0;i<10;i++){const r=i%2?.22:.5,a=i*Math.PI/5+Math.PI/2;(i?s.lineTo:s.moveTo).call(s,Math.cos(a)*r,Math.sin(a)*r);}s.closePath();
 const g=new THREE.ExtrudeGeometry(s,{depth:.14,bevelEnabled:false});g.translate(0,0,-.07);
 const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:0xffd23a,emissive:0xffa800,emissiveIntensity:.7,metalness:.85,roughness:.25}));m.castShadow=true;m.add(new THREE.PointLight(0xffc040,.9,7));return m;}

function puff(x,z,n,k,v,g,life){for(let i=0;i<n;i++){
 const pCol=i%3===0?0xffd438:k;
 const m=new THREE.Mesh(new THREE.SphereGeometry(.12,6,6),new THREE.MeshBasicMaterial({color:pCol,transparent:true}));
 m.position.set(x,.1,z);const a=Math.random()*6.28,s=Math.random()*v;m.userData={v:new THREE.Vector3(Math.cos(a)*s,Math.random()*v*.8,Math.sin(a)*s),g,life,max:life};D.add(m);fx.push(m);}}

let th=0,ph=.9,rad=30,fitR=30;
function fit(){const t=Math.tan(22.5*Math.PI/180)*Math.min(innerWidth/innerHeight,1);rad=fitR=cl((N*P/2+1.8)/t,11,90);}
function cam(){
    shake*=.92;
    const j=()=>(Math.random()-.5)*shake;
    C.position.set(rad*Math.sin(ph)*Math.sin(th)+j(), rad*Math.cos(ph)+j(), rad*Math.sin(ph)*Math.cos(th)+j());
    C.lookAt(0,0,0);
}
function resize(){R.setSize(innerWidth,innerHeight);C.aspect=innerWidth/innerHeight;C.updateProjectionMatrix();fit();}
addEventListener('resize',resize);resize();

const ptr=new Map(),pd=()=>{const a=[...ptr.values()];return Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)};let st=null,pl0=0;const cv=$('cv');
cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);ptr.set(e.pointerId,{x:e.clientX,y:e.clientY});st={t:Date.now(),m:0};if(ptr.size==2){pl0=pd();st.m=99;}});
cv.addEventListener('pointermove',e=>{const o=ptr.get(e.pointerId);if(!o)return;const dx=e.clientX-o.x,dy=e.clientY-o.y;o.x=e.clientX;o.y=e.clientY;
 if(ptr.size==1){
     st.m+=Math.abs(dx)+Math.abs(dy);
     if(st.m>10){
         th-=dx*.006;
         ph=cl(ph-dy*.005, 0.05, Math.PI - 0.05);
     }
 }
 else if(ptr.size==2){const d=pd();rad=cl(rad*pl0/d, 4, 150);pl0=d;}});
const up=(e,tp)=>{ptr.delete(e.pointerId);if(tp&&!ptr.size&&st&&st.m<10&&Date.now()-st.t<600)tap(e.clientX,e.clientY);if(!ptr.size)st=null;};
cv.addEventListener('pointerup',e=>up(e,1));cv.addEventListener('pointercancel',e=>up(e,0));

/* ====== أوفلاين شبكة محلية و QR (بدون إنترنت إطلاقاً) ====== */
let peerConnection=null, dataChannel=null, isHost=false, myPlayerId=0;
let localServerUrl=null, pollAbort=null, currentFacing='environment';
const rtcConfig={iceServers:[]};

function updateNetStatus(text,bg,color){
    const d=$('netStatus');
    if(!d)return;
    d.textContent=text;
    if(bg)d.style.background=bg;
    if(color)d.style.color=color;
}

function waitIce(pc){
    return new Promise(res=>{
        if(pc.iceGatheringState==='complete')return res();
        const t=setTimeout(res,2500);
        pc.addEventListener('icegatheringstatechange',()=>{
            if(pc.iceGatheringState==='complete'){clearTimeout(t);res();}
        });
    });
}

// ضغط كود SDP
const enc=d=>d.type[0]+d.sdp.replace(/\r\n/g,'\n');
const dec=s=>({type:s[0]=='o'?'offer':'answer',sdp:s.slice(1).replace(/\n/g,'\r\n')});

function setLocalCode(t){
    const loc=$('localCode');if(loc)loc.value=t;
    const box=$('qrBox');if(!box)return;
    box.innerHTML='';
    try{
        new QRCode(box,{
            text:t,
            width:240,
            height:240,
            colorDark:'#000000',
            colorLight:'#ffffff',
            correctLevel:QRCode.CorrectLevel.M
        });
        box.style.display='block';
    }catch(e){
        try{
            new QRCode(box,{text:t,width:240,height:240,correctLevel:QRCode.CorrectLevel.L});
            box.style.display='block';
        }catch(err){
            box.style.display='none';
            toast('الكود كبير، يرجى استخدام النسخ واللصق');
        }
    }
}

// ماسح الـ QR أوفلاين مع التركيز التلقائي (Auto-focus) والاستهلاك الفائق الكفاءة
async function scanQR(){
    const box=$('scanner'),vid=$('scanVid'),scanBox=$('scanBox'),ring=$('focusRing');
    const torchBtn=$('scanTorch'),badge=$('afBadge');
    let stream=null,currentTrack=null;
    
    async function startCam(facing){
        if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;currentTrack=null;}
        // طلب الكاميرا مع تفعيل خاصية التركيز التلقائي المستمر continuous auto-focus
        const constraints={
            video:{
                facingMode:{ideal:facing},
                width:{ideal:1280,min:640},
                height:{ideal:720,min:480},
                frameRate:{ideal:30,max:30},
                advanced:[
                    {focusMode:'continuous'},
                    {exposureMode:'continuous'},
                    {whiteBalanceMode:'continuous'}
                ]
            }
        };
        try{
            stream=await navigator.mediaDevices.getUserMedia(constraints);
        }catch(e){
            try{
                stream=await navigator.mediaDevices.getUserMedia({
                    video:{facingMode:{ideal:facing},advanced:[{focusMode:'continuous'}]}
                });
            }catch(err){
                try{
                    stream=await navigator.mediaDevices.getUserMedia({video:true});
                }catch(e3){
                    toast('تعذّر فتح الكاميرا، تأكد من إعطاء الإذن للتطبيق');
                    return false;
                }
            }
        }

        vid.srcObject=stream;
        try{await vid.play();}catch(e){}

        // فحص قدرات الكاميرا وتأكيد التركيز التلقائي المستمر Auto-focus والفلاش
        const track=stream.getVideoTracks()[0];
        currentTrack=track;
        if(track){
            try{
                const caps=track.getCapabilities?track.getCapabilities():{};
                const adv={};
                if(caps.focusMode&&caps.focusMode.includes('continuous')){
                    adv.focusMode='continuous';
                    if(badge)badge.textContent='⚡ تركيز تلقائي مستمر (Auto-focus: ON)';
                }
                if(caps.exposureMode&&caps.exposureMode.includes('continuous'))adv.exposureMode='continuous';
                if(Object.keys(adv).length>0&&track.applyConstraints){
                    await track.applyConstraints({advanced:[adv]});
                }

                // زر الفلاش إذا كان مدعوماً
                if(torchBtn){
                    if(caps.torch){
                        torchBtn.style.display='block';
                        let torchActive=false;
                        torchBtn.onclick=async()=>{
                            torchActive=!torchActive;
                            try{
                                await track.applyConstraints({advanced:[{torch:torchActive}]});
                                torchBtn.textContent=torchActive?'💡 إطفاء الفلاش':'💡 فلاش';
                            }catch(e){}
                        };
                    }else{
                        torchBtn.style.display='none';
                    }
                }
            }catch(err){}
        }
        return true;
    }

    const ok=await startCam(currentFacing);
    if(!ok)return null;
    box.style.display='flex';

    // ميزة اللمس للتركيز الفوري Tap-to-focus
    if(scanBox){
        scanBox.onclick=(e)=>{
            const rect=scanBox.getBoundingClientRect();
            const x=e.clientX-rect.left;
            const y=e.clientY-rect.top;
            if(ring){
                ring.style.left=x+'px';
                ring.style.top=y+'px';
                ring.style.display='block';
                ring.style.animation='none';
                ring.offsetHeight; // trigger reflow
                ring.style.animation='pulseFocus 0.6s ease-out forwards';
            }
            if(currentTrack&&currentTrack.applyConstraints){
                try{
                    currentTrack.applyConstraints({
                        advanced:[{focusMode:'continuous'},{exposureMode:'continuous'}]
                    }).catch(()=>{});
                }catch(e){}
            }
        };
    }

    // كانفاس مخصص لمعالجة منطقة منتصف الإطار فقط لتوفير البطارية والمعالج بنسبة 80%
    const canvas=document.createElement('canvas');
    const ctx=canvas.getContext('2d',{willReadFrequently:true});
    canvas.width=360;
    canvas.height=360;

    return new Promise(res=>{
        let active=true,animId=null,lastScan=0;
        const cleanup=val=>{
            if(!active)return;
            active=false;
            if(animId)cancelAnimationFrame(animId);
            if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;currentTrack=null;}
            box.style.display='none';
            res(val);
        };

        const cancelBtn=$('scanCancel');
        if(cancelBtn)cancelBtn.onclick=()=>cleanup(null);

        const flipBtn=$('scanFlip');
        if(flipBtn)flipBtn.onclick=async()=>{
            currentFacing=currentFacing==='environment'?'user':'environment';
            await startCam(currentFacing);
        };

        const tick=()=>{
            if(!active)return;
            const now=performance.now();

            // فحص الإطار كل 65ms فقط لتوفير طاقة البطارية ومنع ارتفاع حرارة الجهاز
            if(now-lastScan>=65&&vid.readyState===vid.HAVE_ENOUGH_DATA&&vid.videoWidth>0){
                lastScan=now;

                // اقتصاص منطقة المربع المركزي فقط (Center Crop) لسرعة فك التشفير الفورية
                const minDim=Math.min(vid.videoWidth,vid.videoHeight);
                const cropSize=Math.floor(minDim*0.7);
                const sx=Math.floor((vid.videoWidth-cropSize)/2);
                const sy=Math.floor((vid.videoHeight-cropSize)/2);

                ctx.drawImage(vid,sx,sy,cropSize,cropSize,0,0,360,360);
                const imgData=ctx.getImageData(0,0,360,360);

                let decoded=null;
                const scannerFn=typeof jsQR!=='undefined'?jsQR:(typeof self!=='undefined'&&self.jsQR?self.jsQR:null);
                if(typeof scannerFn==='function'){
                    const r=scannerFn(imgData.data,360,360,{inversionAttempts:'dontInvert'});
                    if(r&&r.data)decoded=r.data;
                }

                if(decoded&&decoded.trim()){
                    if(window.AndroidBridge&&window.AndroidBridge.vibrate)try{window.AndroidBridge.vibrate(70);}catch(e){}
                    sStar();
                    cleanup(decoded.trim());
                    return;
                }
            }
            animId=requestAnimationFrame(tick);
        };
        animId=requestAnimationFrame(tick);
    });
}

// إنشاء الغرفة للمضيف (Host)
async function createOffer(){
    // 1. محاولة استخدام سيرفر الأندرويد المحلي (Hotspot / Wi-Fi) المدمج
    if(window.AndroidBridge&&typeof window.AndroidBridge.startLocalServer==='function'){
        try{
            const sUrl=window.AndroidBridge.startLocalServer();
            if(sUrl){
                localServerUrl=sUrl;
                const r=await fetch(sUrl+'/createRoom?np=2');
                const data=await r.json();
                if(data&&data.ok){
                    isHost=true;myPlayerId=0;mode='lan';roomCode=data.code;
                    $('roomCodeVal').textContent=data.code;
                    $('roomCodeDisplay').style.display='block';
                    const qrText='QRM:'+sUrl+'#'+data.code;
                    setLocalCode(qrText);
                    updateNetStatus('✅ الغرفة جاهزة أوفلاين! اطلب من الضيف مسح رمز الـ QR','#3a2a12','#3fe07a');
                    startLocalPolling(sUrl,data.code);
                    return;
                }
            }
        }catch(e){
            console.warn('Local android server fallback to WebRTC',e);
        }
    }

    // 2. البديل المباشر: WebRTC P2P
    try{
        if(peerConnection)peerConnection.close();
        isHost=true;myPlayerId=0;NP=2;mode='lan';
        peerConnection=new RTCPeerConnection(rtcConfig);
        dataChannel=peerConnection.createDataChannel("egyptCorridor");
        setupDataChannel();
        const offer=await peerConnection.createOffer();
        await peerConnection.setLocalDescription(offer);
        await waitIce(peerConnection);
        const codeText=enc(peerConnection.localDescription);
        setLocalCode(codeText);
        updateNetStatus("✅ تم إنشاء الـ QR! اطلب من اللاعب الثاني مسحه بكاميرته","#3a2a12","#f2c14e");
    }catch(e){toast("خطأ في إنشاء الاتصال: "+e.message);}
}

// انضمام الضيف (Guest) بالكود أو نتيجة مسح الـ QR
async function connectWithCode(txt){
    const raw=(typeof txt==='string'?txt:$('remoteCode').value).trim();
    if(!raw)return toast("يرجى مسح رمز الـ QR أو كتابة الكود");

    // فحص إن كان الرابط من السيرفر الأوفلاين للشبكة المحلية
    if(raw.startsWith('QRM:')||raw.startsWith('http://')||raw.startsWith('https://')){
        const clean=raw.startsWith('QRM:')?raw.slice(4):raw;
        const parts=clean.split('#');
        const sUrl=parts[0],code=parts[1];
        if(sUrl&&code){
            updateNetStatus("جاري الاتصال بالمضيف عبر الشبكة المحلية...","#3a2a12","#f2c14e");
            try{
                const r=await fetch(sUrl+'/joinRoom?code='+encodeURIComponent(code));
                const d=await r.json();
                if(d&&d.ok){
                    isHost=false;myPlayerId=d.playerId;mode='lan';roomCode=d.code;
                    localServerUrl=sUrl;
                    updateNetStatus("✅ تم الاتصال بنجاح! جاري بدء اللعبة...","#3a2a12","#3fe07a");
                    setTimeout(()=>{$('netModal').style.display='none';},600);
                    startLocalPolling(sUrl,d.code);
                    return;
                }else{
                    toast((d&&d.error)||"فشل الانضمام للغرفة");
                    return;
                }
            }catch(e){
                toast("تعذّر الاتصال بجهاز المضيف: "+e.message);
                return;
            }
        }
    }

    // اتصال WebRTC P2P
    try{
        const parsed=dec(raw);
        if(!peerConnection){
            isHost=false;myPlayerId=1;mode='lan';
            peerConnection=new RTCPeerConnection(rtcConfig);
            peerConnection.ondatachannel=(e)=>{dataChannel=e.channel;setupDataChannel();};
            await peerConnection.setRemoteDescription(new RTCSessionDescription(parsed));
            const answer=await peerConnection.createAnswer();
            await peerConnection.setLocalDescription(answer);
            await waitIce(peerConnection);
            const ansText=enc(peerConnection.localDescription);
            setLocalCode(ansText);
            updateNetStatus("اعرض هذا الـ QR للمضيف ليمسحه لإنهاء الربط","#3a2a12","#f2c14e");
        }else{
            await peerConnection.setRemoteDescription(new RTCSessionDescription(parsed));
            updateNetStatus("جاري الربط النهائي...","#3a2a12","#3fe07a");
        }
    }catch(e){toast("الكود غير صحيح: "+e.message);}
}

// استقبال الرسائل الأوفلاين عبر الخادم المحلي المدمج
async function startLocalPolling(url,code){
    if(pollAbort)pollAbort.abort();
    pollAbort=new AbortController();
    while(mode==='lan'&&roomCode===code){
        try{
            const res=await fetch(url+'/poll?code='+encodeURIComponent(code)+'&pid='+myPlayerId,{
                signal:pollAbort.signal
            });
            const pkt=await res.json();
            if(pkt.type==='playerJoined'){
                updateNetStatus('✅ تم انضمام اللاعب الآخر! جاري البدء...','#3a2a12','#3fe07a');
                setTimeout(()=>{
                    $('netModal').style.display='none';
                    if(isHost)startGameSession();
                },500);
            }else if(pkt.type==='state'){
                applyRemoteState(pkt.data);
            }else if(pkt.type==='impact'){
                impact({position:new THREE.Vector3(pkt.data.x,0,pkt.data.z)});
            }
        }catch(e){
            if(e.name==='AbortError')break;
            await new Promise(r=>setTimeout(r,800));
        }
    }
}

function setupDataChannel(){
    dataChannel.onopen=()=>{
        updateNetStatus("متصل بنجاح!","#3a2a12","#3fe07a");
        setTimeout(()=>{
            $('netModal').style.display='none';
            if(isHost){startGameSession();}
        },500);
    };
    dataChannel.onclose=()=>{
        updateNetStatus("انقطع الاتصال","#3a2a12","#e03737");
        toast('انقطع الاتصال بالجهاز الآخر');
    };
    dataChannel.onmessage=(e)=>{
        try{
            const packet=JSON.parse(e.data);
            if(packet.type==='STATE')applyRemoteState(packet.data);
            else if(packet.type==='IMPACT')impact({position:new THREE.Vector3(packet.x,0,packet.z)});
        }catch(err){}
    };
}

function broadcastState(){
    if(socket&&roomCode)return socket.emit('state',G);
    if(dataChannel&&dataChannel.readyState==='open')dataChannel.send(JSON.stringify({type:'STATE',data:G}));
    if(localServerUrl&&roomCode){
        fetch(localServerUrl+'/state?code='+encodeURIComponent(roomCode),{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify(G)
        }).catch(()=>{});
    }
}

function sendImpactPacket(x,z){
    if(socket&&roomCode)return socket.emit('impact',{x,z});
    if(dataChannel&&dataChannel.readyState==='open')dataChannel.send(JSON.stringify({type:'IMPACT',x:x,z:z}));
    if(localServerUrl&&roomCode){
        fetch(localServerUrl+'/impact?code='+encodeURIComponent(roomCode),{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({x:x,z:z})
        }).catch(()=>{});
    }
}

/* ====== أونلاين (Node.js + Socket.io) — بجانب الوضع الأوفلاين ====== */
let socket=null, roomCode=null;
const updateOnStatus=(t,color)=>{const d=$('onStatus');d.textContent=t;d.style.color=color||'#f2c14e';};

function loadIO(url){
    return new Promise((res,rej)=>{
        if(window.io)return res();
        const sc=document.createElement('script');
        sc.src=url+'/socket.io/socket.io.js';
        sc.onload=res;sc.onerror=()=>rej(new Error('تعذّر الوصول للسيرفر، تأكد من العنوان والإنترنت'));
        document.head.appendChild(sc);
    });
}

async function netInit(){
    if(socket&&socket.connected)return socket;
    const url=$('srvUrl').value.trim().replace(/\/$/,'');
    if(!url){alert('اكتب عنوان السيرفر أولاً');return null;}
    try{localStorage.setItem('srvUrl',url);}catch(e){}
    try{await loadIO(url);}catch(e){alert(e.message);return null;}
    if(socket)socket.disconnect();
    socket=io(url);
    socket.on('connect',()=>updateOnStatus('متصل بالسيرفر','#3fe07a'));
    socket.on('connect_error',()=>updateOnStatus('تعذّر الاتصال بالسيرفر','#e03737'));
    socket.on('disconnect',()=>updateOnStatus('انقطع الاتصال بالسيرفر','#e03737'));
    socket.on('roomUpdate',({count,np})=>updateOnStatus('اللاعبون في الغرفة: '+count+'/'+np));
    socket.on('roomFull',()=>{
        $('onlineModal').style.display='none';
        if(isHost)startGameSession();
    });
    socket.on('state',data=>applyRemoteState(data));
    socket.on('impact',({x,z})=>impact({position:new THREE.Vector3(x,0,z)}));
    socket.on('peerLeft',()=>{
        toast('خرج أحد اللاعبين وانتهت الغرفة');
        roomCode=null;$('win').style.display='none';$('menu').style.display='flex';
    });
    return socket;
}

async function createRoom(){
    if(!(await netInit()))return;
    isHost=true;myPlayerId=0;
    socket.emit('createRoom',{np:NP},res=>{
        if(!res||!res.ok)return alert('تعذّر إنشاء الغرفة');
        roomCode=res.code;
        $('roomCodeBox').textContent=res.code;
        updateOnStatus('أرسل الكود للاعبين ('+1+'/'+res.np+')');
    });
}

async function joinRoom(){
    const code=$('joinCode').value.trim().toUpperCase();
    if(!code)return alert('أدخل كود الغرفة أولاً!');
    if(!(await netInit()))return;
    isHost=false;
    socket.emit('joinRoom',{code},res=>{
        if(!res||!res.ok)return alert((res&&res.error)||'فشل الانضمام');
        myPlayerId=res.playerId;roomCode=res.code;NP=res.np;
        updateOnStatus('تم الانضمام، بانتظار باقي اللاعبين','#3fe07a');
    });
}

function leaveOnline(){
    if(socket){socket.disconnect();socket=null;}
    roomCode=null;
}

function applyRemoteState(remoteG){
    G=remoteG; WIN=G.WIN||WIN; N=G.N||N; NP=G.NP||NP; c=(N-1)/2;
    buildBoard(); D.clear();
    pawns=G.p.map((p,i)=>{const o=mkPawn(COL[i]);o.position.set(X(p.x),0,X(p.y));D.add(o);return o;});
    G.walls.forEach(w=>{const m=mkWall(w,COL[w.c]);m.position.y=0;D.add(m);});
    if(WIN>=3&&G.star){star=mkStar();star.position.set(X(G.star.x),1,X(G.star.y));D.add(star);}
    clearHL();
    if(human()&&G.act=='move')setAct('move');else ui();
    if(G.over){$('wt').textContent='🏆 انتهت اللعبة!';$('win').style.display='flex';}
}

const isBot=i=>mode=='single'&&i>0,human=()=>{
    if(mode=='lan')return G&&!G.over&&!G.lock&&G.turn===myPlayerId;
    return G&&!G.over&&!G.lock&&!isBot(G.turn);
};
function toast(t){const e=$('toast');e.textContent=t;e.style.opacity=1;clearTimeout(toast.h);toast.h=setTimeout(()=>e.style.opacity=0,2600);}
const WT=()=>['','الهدف: الوصول إلى الضلع المقابل لبيتك','سباق: الجميع من جهة واحدة، والهدف الجهة المقابلة','الهدف: أول من يصل إلى النجمة في المنتصف','النجمة تنتقل بعد كل '+N+' حركات — أول من يصل إليها يفوز'][WIN];

function startGameSession(){
    const n=cl(Math.floor(+$('wn').value||10),1,99999),m=N-1;c=m/2;
    buildBoard(); D.clear(); fx=[]; hl=[]; ghost=null; star=null;
    let base=WIN==2?Array.from({length:NP},(_,i)=>({x:Math.round((i+1)*m/(NP+1)),y:m,ax:'y',gv:0})):[{x:c,y:m,ax:'y',gv:0},{x:c,y:0,ax:'y',gv:m},{x:0,y:c,ax:'x',gv:m},{x:m,y:c,ax:'x',gv:0}].slice(0,NP);
    const keys=Object.keys(PR),ps=$('ps').value;
    G={p:base.map(p=>({...p,w:n})),walls:[],turn:0,act:'move',over:false,t:1,totalMoves:0,mc:0,lock:0,star:{x:c,y:c},bot:base.map(()=>ps=='mix'?keys[Math.floor(Math.random()*5)]:ps),WIN,N,NP};
    pawns=G.p.map((p,i)=>{const o=mkPawn(COL[i]);o.position.set(X(p.x),0,X(p.y));D.add(o);return o;});
    if(WIN>=3){star=mkStar();star.position.set(X(c),1,X(c));D.add(star);}
    pv={x:Math.max(0,c-1),y:Math.max(0,c-1),o:'h'};$('win').style.display='none';th=0;ph=.9;fit();setAct('move');toast(WT());
    if(mode=='lan') broadcastState();
}

function newGame(){
    if(mode=='lan'&&!isHost)return toast('المضيف فقط يستطيع بدء لعبة جديدة');
    startGameSession();
}

function notifyStatsBridge(stats){
    if(window.AndroidBridge&&typeof window.AndroidBridge.updateGameStats==='function'){
        try{window.AndroidBridge.updateGameStats(JSON.stringify(stats));}catch(e){}
    }
    if(window.parent&&window.parent!==window){
        try{window.parent.postMessage({type:'GAME_STATS_UPDATE',stats},'*');}catch(e){}
    }
}

function clearHL(){hl.forEach(h=>D.remove(h));hl=[];if(ghost){D.remove(ghost);ghost=null;}}
function setAct(a){G.act=a;clearHL();
 if(human()&&a=='move')moves(G.turn).forEach(([x,y])=>{const k=new THREE.Mesh(new THREE.CircleGeometry(.4,24),new THREE.MeshBasicMaterial({color:0x37e07a,transparent:true,opacity:.7}));
  k.rotation.x=-Math.PI/2;k.position.set(X(x),.03,X(y));D.add(k);hl.push(k);});
 if(human()&&a=='wall')showGhost();ui();}
function showGhost(){if(ghost)D.remove(ghost);const e=wallErr(pv);ghost=mkWall(pv,e?0xff3030:0x37e07a,true);D.add(ghost);$('ok').style.opacity=e?.45:1;if(e){toast(e);sErr();}else sTick();}

function ui(){
    if(!G)return;
    const t=G.turn;
    const totalMoves=G.totalMoves||0;

    $('pn').innerHTML='<span id="dot" style="background:'+HEX[t]+'"></span>دور اللاعب '+NAMES[t]+(isBot(t)?' (الكمبيوتر)':'');

    // لوحة إحصائيات الجدران المتبقية لكل لاعب داخل الـ HUD
    const pw=$('playerWallsList');
    if(pw){
        pw.innerHTML=G.p.map((p,j)=>{
            const isCur=j===t;
            return '<div class="p-wall-badge '+(isCur?'active':'')+'">'+
                '<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:'+HEX[j]+';"></span>'+
                '<span style="color:'+HEX[j]+';">'+NAMES[j]+':</span>'+
                '<span style="color:#fff;">🧱 '+p.w+'</span>'+
            '</div>';
        }).join('');
    }

    // إحصائية الحركات الإجمالية
    const mc=$('totalMovesCount');
    if(mc){
        mc.innerHTML='🎯 الحركات: <b>'+totalMoves+'</b> • الجولة: <b>'+G.t+'</b>';
    }

    $('st').innerHTML=(WIN==4?' • النجمة بعد '+(N-G.mc):'');
    const w=G.act=='wall';$('mv').style.display=$('wl').style.display=w?'none':'';$('ok').style.display=$('no').style.display=$('ro').style.display=w?'':'none';
    $('bar').style.visibility=human()?'visible':'hidden';

    // تحديث الـ Bridge لحظياً
    notifyStatsBridge({
        turn:t,
        turnPlayerName:NAMES[t],
        turnPlayerColor:HEX[t],
        totalMoves:totalMoves,
        round:G.t,
        players:G.p.map((p,j)=>({
            id:j,
            name:NAMES[j],
            color:HEX[j],
            walls:p.w,
            x:p.x,
            y:p.y
        }))
    });
}

function tap(px,py){if(!human()||$('menu').style.display=='flex'||$('netModal').style.display=='flex'||$('onlineModal').style.display=='flex')return;
 const ray=new THREE.Raycaster(),v=new THREE.Vector3();ray.setFromCamera(new THREE.Vector2(px/innerWidth*2-1,-(py/innerHeight)*2+1),C);
 if(!ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0,1,0),0),v))return;
 const gx=v.x/P+c,gz=v.z/P+c;
 if(G.act=='move'){const x=Math.round(gx),y=Math.round(gz);
  if(moves(G.turn).some(m=>m[0]==x&&m[1]==y))doMove(G.turn,x,y);else if(inb(x,y)){toast('حركة غير مسموحة');sErr();}}
 else{pv.x=cl(Math.round(gx-.5),0,N-2);pv.y=cl(Math.round(gz-.5),0,N-2);showGhost();}}

function doMove(i,x,y){
    G.totalMoves=(G.totalMoves||0)+1;
    const p=G.p[i];p.x=x;p.y=y;pawns[i].tp={x:X(x),z:X(y)};clearHL();sMove();
    if(isGoal(p,x,y))return win(i);
    if(WIN==4&&++G.mc>=N){G.mc=0;moveStar();}
    end();
}

function moveStar(){const o=G.star,ok=[];
 for(let x=0;x<N;x++)for(let y=0;y<N;y++){if(G.p.some(p=>p.x==x&&p.y==y))continue;G.star={x,y};
  if(G.p.every(p=>dist(p.x,p.y,p,G.walls)<1e9))ok.push({x,y,d:Math.min(...G.p.map(p=>Math.abs(p.x-x)+Math.abs(p.y-y)))});}
 const far=ok.filter(k=>k.d>=Math.floor(N/2)),pool=far.length?far:ok.sort((a,b)=>b.d-a.d).slice(0,3);
 G.star=pool.length?pool[Math.floor(Math.random()*pool.length)]:o;
 puff(X(o.x),X(o.y),16,0xffd23a,.12,.004,40);star.position.set(X(G.star.x),1,X(G.star.y));star.scale.setScalar(.01);sStar();toast('✨ انتقلت النجمة إلى مكان جديد!');}

function place(w){
    G.totalMoves=(G.totalMoves||0)+1;
    G.walls.push({x:w.x,y:w.y,o:w.o,c:G.turn});
    G.p[G.turn].w--;
    clearHL();
    G.lock=1;

    const m = mkWall(w, COL[G.turn]);
    m.position.y = 16;

    const mk = new THREE.Mesh(
        new THREE.PlaneGeometry(w.o=='h'?2.4:.5, w.o=='h'?.5:2.4),
        new THREE.MeshBasicMaterial({color:0xff1010, transparent:true, opacity:0})
    );
    mk.rotation.x = -Math.PI/2;
    mk.position.set(m.position.x, .04, m.position.z);
    D.add(mk);
    m.userData.bm.emissive.setHex(0xff2200);

    Object.assign(m.userData, {
        drop: 1,
        vy: 0,
        mk,
        after: () => { G.lock = 0; end(); }
    });

    D.add(m);
    sWhoosh();
    ui();

}

function impact(m){
    if(SND)wallSound.play(); if(window.AndroidBridge && typeof window.AndroidBridge.vibrate === "function") { try { window.AndroidBridge.vibrate(60); } catch(e){} } // صوتك يشتغل لحظة وصول الجدار للوحة
    shake=1.1;L.intensity=3.2;sBoom();
    puff(m.position.x,m.position.z,22,0xc9a35e,.22,-.002,45);
}

function end(){
    G.turn=(G.turn+1)%NP;if(G.turn==0)G.t++;setAct('move');
    if(mode=='lan'){
        broadcastState();
    }else{
        if(isBot(G.turn))setTimeout(aiPlay,900);
    }
}
function win(i){
    G.over=true;pawns[i].spin=1;rad=Math.max(8,rad*.6);ph=.75;clearHL();ui();sWin();shake=.6;
    for(let k=0;k<100;k++){const m=new THREE.Mesh(new THREE.BoxGeometry(.14,.14,.02),new THREE.MeshBasicMaterial({color:[0xf2c14e,0xd62828,0x1d6fe0,0xffffff][k%4]}));
     m.position.set(0,7,0);m.userData={v:new THREE.Vector3((Math.random()-.5)*.3,Math.random()*.15,(Math.random()-.5)*.3),g:.006,life:260,max:260,nf:1};D.add(m);fx.push(m);}
    if(mode=='lan')broadcastState();
    setTimeout(()=>{$('wt').textContent='🏆 فاز اللاعب '+NAMES[i]+'!';$('wt').style.color=HEX[i];$('win').style.display='flex';},1100);
}
function aiPlay(){if(G.over)return;const i=G.turn,me=G.p[i],W=G.walls,ps=PR[G.bot[i]],ds=G.p.map(p=>dist(p.x,p.y,p,W)),dm=ds[i];
 let ld=-1;ds.forEach((d,j)=>{if(j!=i&&(ld<0||d<ds[ld]))ld=j;});const Lp=G.p[ld],dl=ds[ld];let best=null,bg=Math.max(1,dl<dm?ps.th-1:ps.th);
 if(me.w>0&&Math.random()<ps.p)for(let x=Math.max(0,Lp.x-2);x<=Math.min(N-2,Lp.x+1);x++)for(let y=Math.max(0,Lp.y-2);y<=Math.min(N-2,Lp.y+1);y++)for(const o of['h','v']){
  const w={x,y,o};if(wallErr(w))continue;const W2=[...W,w],g=dist(Lp.x,Lp.y,Lp,W2)-dl-(dist(me.x,me.y,me,W2)-dm);if(g>=bg){bg=g;best=w;}}
 if(best)return place(best);
 const ms=moves(i).map(m=>[dist(m[0],m[1],me,W),m]).sort((a,b)=>a[0]-b[0]);if(!ms.length)return end();doMove(i,ms[0][1][0],ms[0][1][1]);}

function loop(){requestAnimationFrame(loop);const t=performance.now()/1000;

 // Living Torch fire flicker & flame animation
 torchLights.forEach((tl,idx)=>{
     tl.intensity=.95+Math.sin(t*14+idx*1.8)*.25+Math.cos(t*26+idx*3.1)*.15;
 });
 torchFlames.forEach((fl,idx)=>{
     fl.scale.y=.9+Math.sin(t*18+idx*2.1)*.25;
     fl.rotation.y+=.08;
 });

 // Floating desert embers
 embers.forEach(e=>{
     e.position.y+=e.userData.speedY;
     e.position.x+=Math.sin(t*1.5+e.userData.phase)*.01;
     e.position.z+=Math.cos(t*1.5+e.userData.phase)*.01;
     if(e.position.y>15){
         e.position.y=.2;
         e.position.x=(Math.random()-.5)*36;
         e.position.z=(Math.random()-.5)*36;
     }
 });

 pawns.forEach((p,idx)=>{
     const isCurrent=G&&G.turn===idx&&!G.over;
     if(p.userData&&p.userData.auraRing){
         p.userData.auraRing.material.opacity=isCurrent?.65+Math.sin(t*4)*.25:0;
     }
     if(p.spin){
         p.rotation.y+=.05;
         p.position.y=.4+Math.abs(Math.sin(t*3))*.6;
     }
     else if(p.tp){
         const dx=p.tp.x-p.position.x,dz=p.tp.z-p.position.z,d=Math.hypot(dx,dz);
         p.position.x+=dx*.22;
         p.position.z+=dz*.22;
         p.position.y=Math.sin(Math.min(d,1)*Math.PI)*.65;
         p.rotation.y=Math.atan2(dx,dz);
         if(d<.02){p.position.set(p.tp.x,0,p.tp.z);p.tp=null;p.rotation.y=0;}
     }
     else{
         p.position.y=isCurrent?Math.sin(t*3.5)*.06:0;
     }
 });
 if(star&&G){const s=star.scale.x;star.scale.setScalar(Math.min(1,s+.04));star.rotation.y+=.04;star.position.y=1+Math.sin(t*2)*.15;star.position.x+=(X(G.star.x)-star.position.x)*.5;star.position.z+=(X(G.star.y)-star.position.z)*.5;}
 [...D.children].forEach(m=>{const u=m.userData;if(!u.drop)return;
  u.vy+=.012;
  m.position.y-=u.vy;
  u.mk.material.opacity=cl(.1+.6*(1-m.position.y/16),0,.7);u.bm.emissiveIntensity=.5+.5*Math.sin(t*40);
  if(m.position.y<=0){
      m.position.y=0;u.drop=0;D.remove(u.mk);u.bm.emissive.setHex(0);
      impact(m);if(mode=='lan')sendImpactPacket(m.position.x,m.position.z);u.after();
  }
});
 fx.slice().forEach(m=>{const u=m.userData;u.v.y-=u.g;m.position.add(u.v);m.rotation.x+=.2;if(!u.nf)m.material.opacity=u.life/u.max;if(m.position.y<-.3){m.position.y=-.3;u.v.set(0,0,0);}if(--u.life<=0){D.remove(m);fx.splice(fx.indexOf(m),1);}});
 L.intensity+=(1.15-L.intensity)*.12;if(G&&G.over)th+=.004;cam();R.render(S,C);}

const setN=d=>{N=cl(N+d*2,5,25);$('nv').textContent=N+'×'+N;};
$('nm').onclick=()=>setN(-1);$('npp').onclick=()=>setN(1);
$('npb').onclick=e=>{const b=e.target.closest('button');if(!b)return;[...$('npb').children].forEach(x=>x.classList.remove('on'));b.classList.add('on');NP=+b.dataset.v;};
$('wm').onchange=e=>WIN=+e.target.value;

const start=m=>{au();$('menu').style.display='none';
    NP=+$('npb').querySelector('.on').dataset.v;
    isHost=false;myPlayerId=0;leaveOnline();
    if(m=='lan'){mode='lan';NP=2;$('netModal').style.display='flex';}
    else if(m=='net'){mode='lan';$('onlineModal').style.display='flex';}
    else{mode=m;newGame();}};
$('m1').onclick=()=>start('single');$('m2').onclick=()=>start('local');
$('m3').onclick=()=>start('lan');
$('m4').onclick=()=>start('net');

$('btnCreateOffer').onclick=createOffer;
$('btnConnect').onclick=()=>connectWithCode();
$('btnScan').onclick=async()=>{const t=await scanQR();if(t)connectWithCode(t);};
$('btnCopyLocal').onclick=()=>{
    const box=$('localCode');
    if(!box.value)return toast("لا يوجد كود للنسخ بعد!");
    navigator.clipboard.writeText(box.value).then(()=>toast("✨ تم نسخ الكود"));
};
$('btnPasteRemote').onclick=()=>{
    navigator.clipboard.readText().then(t=>{$('remoteCode').value=t;}).catch(()=>toast("الصق الكود يدوياً في المربع"));
};

$('btnCloseNet').onclick=()=>{
    $('netModal').style.display='none';$('menu').style.display='flex';
    if(peerConnection){peerConnection.close();peerConnection=null;dataChannel=null;}
    mode='local';
};

try{$('srvUrl').value=localStorage.getItem('srvUrl')||(location.protocol.startsWith('http')?location.origin:'');}catch(e){}
$('onCreate').onclick=createRoom;
$('onJoin').onclick=joinRoom;
$('onCopy').onclick=()=>{
    if(!roomCode)return toast('لا يوجد كود بعد!');
    navigator.clipboard.writeText(roomCode).then(()=>toast('✨ تم نسخ الكود'));
};
$('onClose').onclick=()=>{leaveOnline();$('onlineModal').style.display='none';$('menu').style.display='flex';mode='local';};

$('mn').onclick=()=>$('menu').style.display='flex';$('rc').onclick=()=>{th=0;ph=.9;fit();};
$('sn').onclick=()=>{SND=!SND;$('sn').textContent=SND?'🔊':'🔇';};
$('again').onclick=()=>newGame();$('mv').onclick=()=>setAct('move');
$('wl').onclick=()=>G.p[G.turn].w>0?setAct('wall'):toast('لا توجد جدران متبقية');
$('no').onclick=()=>setAct('move');$('ro').onclick=()=>{pv.o=pv.o=='h'?'v':'h';showGhost();};
$('ok').onclick=()=>{const e=wallErr(pv);if(e){sErr();return toast(e);}place(pv);};

startGameSession();$('menu').style.display='flex';loop();

// Android Back Button handler
window.handleAndroidBack = function() {
    var scanner = document.getElementById('scanner');
    if (scanner && scanner.style.display === 'flex') {
        var c = document.getElementById('scanCancel'); if (c) c.click(); return true;
    }
    var win = document.getElementById('win');
    if (win && win.style.display === 'flex') {
        win.style.display = 'none';
        document.getElementById('menu').style.display = 'flex';
        return true;
    }
    var net = document.getElementById('netModal');
    if (net && net.style.display === 'flex') {
        document.getElementById('btnCloseNet').click();
        return true;
    }
    var onm = document.getElementById('onlineModal');
    if (onm && onm.style.display === 'flex') {
        document.getElementById('onClose').click();
        return true;
    }
    var m = document.getElementById('menu');
    if (m && m.style.display === 'flex' && window.G && !window.G.over) {
        m.style.display = 'none';
        return true;
    }
    if (m && m.style.display !== 'flex') {
        m.style.display = 'flex';
        return true;
    }
    return false;
};
