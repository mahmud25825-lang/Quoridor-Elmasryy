package com.elmasry.quoridor

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.widget.Toast

/**
 * JavaScript interface to bridge native Android capabilities into the Quoridor Elmasry web game.
 * Includes vibration, offline local hotspot/Wi-Fi server control, and system hooks.
 */
class WebAppInterface(
    private val context: Context,
    private val localServer: LocalGameServer,
    private val onExitRequested: () -> Unit
) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    @JavascriptInterface
    fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    @JavascriptInterface
    fun vibrate(milliseconds: Long) {
        try {
            vibrator?.let { vib ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = VibrationEffect.createOneShot(
                        milliseconds.coerceIn(10L, 500L),
                        VibrationEffect.DEFAULT_AMPLITUDE
                    )
                    vib.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    vib.vibrate(milliseconds.coerceIn(10L, 500L))
                }
            }
        } catch (_: Exception) {
            // Ignore vibration errors gracefully
        }
    }

    @JavascriptInterface
    fun startLocalServer(): String {
        return try {
            localServer.start()
        } catch (e: Exception) {
            ""
        }
    }

    @JavascriptInterface
    fun stopLocalServer() {
        try {
            localServer.stop()
        } catch (_: Exception) {}
    }

    @JavascriptInterface
    fun getLocalIp(): String {
        return try {
            localServer.getLocalIpAddress()
        } catch (e: Exception) {
            "127.0.0.1"
        }
    }

    @JavascriptInterface
    fun exitApp() {
        onExitRequested()
    }

    @JavascriptInterface
    fun getAppVersion(): String {
        return "1.0.0"
    }

    private var latestGameStatsJson: String = "{}"

    @JavascriptInterface
    fun updateGameStats(statsJson: String) {
        latestGameStatsJson = statsJson
    }

    @JavascriptInterface
    fun getGameStats(): String {
        return latestGameStatsJson
    }

    @JavascriptInterface
    fun isAndroid(): Boolean {
        return true
    }
}
