package com.elmasry.quoridor

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import java.io.*
import java.net.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import org.json.JSONObject

/**
 * High-performance, 100% offline local HTTP & WebSocket signaling server.
 * Enables two Android devices to play Quoridor Elmasry on a local Wi-Fi or portable hotspot
 * without ANY internet connection or external server.
 */
class LocalGameServer(private val context: Context) {

    private val TAG = "LocalGameServer"
    private var serverSocket: ServerSocket? = null
    private var isRunning = false
    private val executor = Executors.newCachedThreadPool()

    // Room Code -> Room state & client listeners
    data class Room(
        val code: String,
        val np: Int,
        val players: MutableList<String> = CopyOnWriteArrayList(),
        var lastStateJson: String? = null,
        val listeners: MutableList<(String) -> Unit> = CopyOnWriteArrayList()
    )

    private val rooms = ConcurrentHashMap<String, Room>()
    var serverPort: Int = 8080
        private set

    fun start(preferredPort: Int = 8080): String {
        if (isRunning && serverSocket != null && !serverSocket!!.isClosed) {
            return "http://${getLocalIpAddress()}:$serverPort"
        }

        var port = preferredPort
        var bound = false

        while (!bound && port < preferredPort + 10) {
            try {
                serverSocket = ServerSocket(port, 50, InetAddress.getByName("0.0.0.0"))
                serverPort = port
                bound = true
            } catch (_: Exception) {
                port++
            }
        }

        if (!bound) {
            serverSocket = ServerSocket(0)
            serverPort = serverSocket!!.localPort
        }

        isRunning = true
        val localIp = getLocalIpAddress()
        val serverUrl = "http://$localIp:$serverPort"
        Log.i(TAG, "Offline Local Server started on $serverUrl")

        executor.execute {
            while (isRunning && serverSocket != null && !serverSocket!!.isClosed) {
                try {
                    val clientSocket = serverSocket!!.accept()
                    clientSocket.soTimeout = 30000
                    executor.execute { handleClient(clientSocket) }
                } catch (e: Exception) {
                    if (!isRunning) break
                }
            }
        }

        return serverUrl
    }

    fun stop() {
        isRunning = false
        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        serverSocket = null
        rooms.clear()
        Log.i(TAG, "Offline Local Server stopped")
    }

    private fun handleClient(socket: Socket) {
        try {
            val input = BufferedReader(InputStreamReader(socket.getInputStream(), "UTF-8"))
            val output = OutputStreamWriter(socket.getOutputStream(), "UTF-8")

            val requestLine = input.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return

            val method = parts[0].uppercase()
            val fullPath = parts[1]
            val path = if (fullPath.contains("?")) fullPath.substringBefore("?") else fullPath
            val query = if (fullPath.contains("?")) fullPath.substringAfter("?") else ""
            val queryParams = parseQuery(query)

            // Read headers
            val headers = mutableMapOf<String, String>()
            var contentLength = 0
            var line: String?
            while (input.readLine().also { line = it } != null) {
                if (line.isNullOrEmpty()) break
                val headerParts = line!!.split(":", limit = 2)
                if (headerParts.size == 2) {
                    val key = headerParts[0].trim().lowercase()
                    val value = headerParts[1].trim()
                    headers[key] = value
                    if (key == "content-length") {
                        contentLength = value.toIntOrNull() ?: 0
                    }
                }
            }

            // Read body if POST
            var body = ""
            if (contentLength > 0) {
                val charBuffer = CharArray(contentLength)
                var readTotal = 0
                while (readTotal < contentLength) {
                    val read = input.read(charBuffer, readTotal, contentLength - readTotal)
                    if (read <= 0) break
                    readTotal += read
                }
                body = String(charBuffer, 0, readTotal)
            }

            // Handle CORS Preflight
            if (method == "OPTIONS") {
                sendResponse(output, 204, "No Content", "text/plain", "")
                socket.close()
                return
            }

            when (path) {
                "/status" -> {
                    val json = JSONObject().apply {
                        put("ok", true)
                        put("ip", getLocalIpAddress())
                        put("port", serverPort)
                        put("activeRooms", rooms.size)
                    }
                    sendResponse(output, 200, "OK", "application/json", json.toString())
                }

                "/createRoom" -> {
                    val np = queryParams["np"]?.toIntOrNull() ?: 2
                    val code = generateRoomCode()
                    val room = Room(code = code, np = np)
                    room.players.add("host")
                    rooms[code] = room

                    val json = JSONObject().apply {
                        put("ok", true)
                        put("code", code)
                        put("playerId", 0)
                        put("np", np)
                    }
                    sendResponse(output, 200, "OK", "application/json", json.toString())
                }

                "/joinRoom" -> {
                    val code = (queryParams["code"] ?: "").uppercase().trim()
                    val room = rooms[code]
                    if (room == null) {
                        val json = JSONObject().apply {
                            put("ok", false)
                            put("error", "الغرفة غير موجودة على هذا الجهاز")
                        }
                        sendResponse(output, 404, "Not Found", "application/json", json.toString())
                    } else if (room.players.size >= room.np) {
                        val json = JSONObject().apply {
                            put("ok", false)
                            put("error", "الغرفة ممتلئة بالكامل")
                        }
                        sendResponse(output, 403, "Forbidden", "application/json", json.toString())
                    } else {
                        val pid = room.players.size
                        room.players.add("guest_$pid")

                        // Notify host via long-poll listener
                        val notifyMsg = JSONObject().apply {
                            put("type", "playerJoined")
                            put("count", room.players.size)
                            put("np", room.np)
                        }.toString()

                        for (listener in room.listeners) {
                            try { listener(notifyMsg) } catch (_: Exception) {}
                        }

                        val json = JSONObject().apply {
                            put("ok", true)
                            put("code", code)
                            put("playerId", pid)
                            put("np", room.np)
                        }
                        sendResponse(output, 200, "OK", "application/json", json.toString())
                    }
                }

                "/state" -> {
                    val code = (queryParams["code"] ?: "").uppercase().trim()
                    val room = rooms[code]
                    if (room != null && body.isNotEmpty()) {
                        room.lastStateJson = body
                        val event = JSONObject().apply {
                            put("type", "state")
                            put("data", JSONObject(body))
                        }.toString()

                        for (listener in room.listeners) {
                            try { listener(event) } catch (_: Exception) {}
                        }
                    }
                    sendResponse(output, 200, "OK", "application/json", "{\"ok\":true}")
                }

                "/impact" -> {
                    val code = (queryParams["code"] ?: "").uppercase().trim()
                    val room = rooms[code]
                    if (room != null && body.isNotEmpty()) {
                        val event = JSONObject().apply {
                            put("type", "impact")
                            put("data", JSONObject(body))
                        }.toString()

                        for (listener in room.listeners) {
                            try { listener(event) } catch (_: Exception) {}
                        }
                    }
                    sendResponse(output, 200, "OK", "application/json", "{\"ok\":true}")
                }

                "/poll" -> {
                    // Long polling for real-time local sync without internet
                    val code = (queryParams["code"] ?: "").uppercase().trim()
                    val room = rooms[code]
                    if (room == null) {
                        sendResponse(output, 404, "Not Found", "application/json", "{\"error\":\"Room not found\"}")
                        socket.close()
                        return
                    }

                    var replied = false
                    val lock = Object()
                    var messageToSend = ""

                    val listener: (String) -> Unit = { msg ->
                        synchronized(lock) {
                            if (!replied) {
                                replied = true
                                messageToSend = msg
                                try { lock.notifyAll() } catch (_: Exception) {}
                            }
                        }
                    }

                    room.listeners.add(listener)

                    synchronized(lock) {
                        try {
                            lock.wait(15000) // 15 sec long poll timeout
                        } catch (_: Exception) {}
                    }

                    room.listeners.remove(listener)

                    if (messageToSend.isNotEmpty()) {
                        sendResponse(output, 200, "OK", "application/json", messageToSend)
                    } else {
                        sendResponse(output, 200, "OK", "application/json", "{\"type\":\"ping\"}")
                    }
                }

                else -> {
                    sendResponse(output, 404, "Not Found", "text/plain", "Not Found")
                }
            }
        } catch (_: Exception) {
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun sendResponse(
        out: OutputStreamWriter,
        statusCode: Int,
        statusText: String,
        contentType: String,
        body: String
    ) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        out.write("HTTP/1.1 $statusCode $statusText\r\n")
        out.write("Content-Type: $contentType; charset=UTF-8\r\n")
        out.write("Content-Length: ${bytes.size}\r\n")
        out.write("Access-Control-Allow-Origin: *\r\n")
        out.write("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n")
        out.write("Access-Control-Allow-Headers: Content-Type\r\n")
        out.write("Connection: close\r\n\r\n")
        out.write(body)
        out.flush()
    }

    private fun parseQuery(query: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        if (query.isEmpty()) return map
        for (param in query.split("&")) {
            val pair = param.split("=", limit = 2)
            if (pair.size == 2) {
                map[URLDecoder.decode(pair[0], "UTF-8")] = URLDecoder.decode(pair[1], "UTF-8")
            } else if (pair.size == 1) {
                map[URLDecoder.decode(pair[0], "UTF-8")] = ""
            }
        }
        return map
    }

    private fun generateRoomCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        var code: String
        do {
            code = (1..4).map { chars.random() }.joinToString("")
        } while (rooms.containsKey(code))
        return code
    }

    fun getLocalIpAddress(): String {
        try {
            // First check Wi-Fi connection
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val wifiIp = wifiManager?.connectionInfo?.ipAddress ?: 0
            if (wifiIp != 0) {
                return String.format(
                    java.util.Locale.US,
                    "%d.%d.%d.%d",
                    wifiIp and 0xff,
                    wifiIp shr 8 and 0xff,
                    wifiIp shr 16 and 0xff,
                    wifiIp shr 24 and 0xff
                )
            }

            // Next check all network interfaces (e.g. portable hotspot wlan0, ap0, etc.)
            val interfaces = NetworkInterface.getNetworkInterfaces()
            var hotspotCandidate = ""
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isLoopback || !iface.isUp) continue

                val addrs = iface.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val host = addr.hostAddress ?: ""
                        if (host.startsWith("192.168.") || host.startsWith("10.") || host.startsWith("172.")) {
                            if (host.startsWith("192.168.43.")) {
                                return host // Android standard hotspot IP
                            }
                            hotspotCandidate = host
                        }
                    }
                }
            }
            if (hotspotCandidate.isNotEmpty()) return hotspotCandidate
        } catch (e: Exception) {
            Log.e(TAG, "Error finding local IP", e)
        }
        return "127.0.0.1"
    }
}
